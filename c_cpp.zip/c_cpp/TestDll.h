#ifdef __cplusplus
extern "C"{
#endif
int __stdcall __declspec(dllexport) cpp_canny();
 
#ifdef __cplusplus
}
#endif