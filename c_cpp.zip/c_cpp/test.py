﻿import ctypes
from PIL import Image
import numpy as np
# 导出函数是__stdcall声明的使用
#dll = ctypes.WinDLL(r"C:\Users\User\Desktop\c_cpp\TestDll.dll")
# 导出函数是__cdecl声明的使用
dll = ctypes.cdll.LoadLibrary(r"C:\Users\User\Desktop\c_cpp\TestDll.dll")
#mat = Image.open(r"C:\Users\User\Desktop\PDE.JPG")
#mat = np.array(mat)
#h,w,c = mat.shape
summmm = getattr(dll, 'cpp_canny')
ret = summmm()
print(ret)