#include "TestDll.h"
#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/core/utility.hpp>
#include <iostream>

#define DLLEXPORT extern "C" __declspec(dllexport)

#ifdef __cplusplus
extern "C"{
#endif


using namespace cv;
DLLEXPORT  int cpp_canny() {
	 cv::Mat image = cv::imread("C:\\Users\\User\\Desktop\\PDE.JPG");
     cv::imshow("test", image);
     cv::waitKey(0);
	 return 0;

	}


#ifdef __cplusplus
}
#endif